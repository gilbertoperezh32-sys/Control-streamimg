import React, { useState, useEffect } from 'react';
import { Users, Server, MessageCircle, Plus, Trash2, RefreshCw, Clock } from 'lucide-react';

export default function App() {
  const [providers, setProviders] = useState(() => JSON.parse(localStorage.getItem('cw_providers')) || []);
  const [clients, setClients] = useState(() => JSON.parse(localStorage.getItem('cw_clients')) || []);
  const [activeTab, setActiveTab] = useState('clients');

  useEffect(() => { localStorage.setItem('cw_providers', JSON.stringify(providers)); }, [providers]);
  useEffect(() => { localStorage.setItem('cw_clients', JSON.stringify(clients)); }, [clients]);

  // Form States
  const [clientForm, setClientForm] = useState({ name: '', phone: '', providerId: '', profileNum: '', date: '' });
  const [providerForm, setProviderForm] = useState({ platform: '', email: '', pin: '', maxProfiles: 5, date: '' });

  const calculateDays = (dateString) => {
    if (!dateString) return 0;
    const diff = new Date(dateString).getTime() - new Date().setHours(0,0,0,0);
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  const getStatusColor = (days) => {
    if (days < 0) return 'bg-red-900/50 text-red-200';
    if (days <= 3) return 'bg-amber-900/50 text-amber-200';
    return 'bg-slate-800 text-slate-200';
  };

  const addClient = (e) => {
    e.preventDefault();
    setClients([...clients, { ...clientForm, id: Date.now().toString() }]);
    setClientForm({ name: '', phone: '', providerId: '', profileNum: '', date: '' });
  };

  const addProvider = (e) => {
    e.preventDefault();
    setProviders([...providers, { ...providerForm, id: Date.now().toString() }]);
    setProviderForm({ platform: '', email: '', pin: '', maxProfiles: 5, date: '' });
  };

  const deleteClient = (id) => setClients(clients.filter(c => c.id !== id));
  const deleteProvider = (id) => {
    setProviders(providers.filter(p => p.id !== id));
    setClients(clients.filter(c => c.providerId !== id)); // Remove associated clients
  };

  const renew = (id, daysToAdd, type) => {
    const list = type === 'client' ? clients : providers;
    const setList = type === 'client' ? setClients : setProviders;
    
    setList(list.map(item => {
      if (item.id === id) {
        const currentDate = new Date(item.date);
        currentDate.setDate(currentDate.getDate() + daysToAdd);
        return { ...item, date: currentDate.toISOString().split('T')[0] };
      }
      return item;
    }));
  };

  const getWhatsAppLink = (phone, name, days, platform) => {
    let num = phone.replace(/\D/g, '');
    if (num.length === 8) num = '502' + num;
    let msg = `Hola ${name}, te escribimos de Ciber World. Tu perfil de ${platform || 'Streaming'} `;
    if (days < 0) msg += `venció hace ${Math.abs(days)} días. ¿Deseas renovarlo?`;
    else if (days <= 3) msg += `está por vencer en ${days} días.`;
    else msg += `está activo y vence en ${days} días.`;
    return `https://wa.me/${num}?text=${encodeURIComponent(msg)}`;
  };

  const activeProfilesCount = clients.length;
  const totalProfilesCapacity = providers.reduce((acc, p) => acc + Number(p.maxProfiles), 0);

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <header className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-indigo-400">Ciber World</h1>
          <p className="text-slate-400">Control de Streaming</p>
        </div>
      </header>

      {/* Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-sm">Clientes Registrados</div>
          <div className="text-3xl font-bold text-white mt-1">{clients.length}</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-sm">Cuentas Madre</div>
          <div className="text-3xl font-bold text-white mt-1">{providers.length}</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
          <div className="text-slate-400 text-sm">Ocupación de Perfiles</div>
          <div className="text-3xl font-bold text-white mt-1">{activeProfilesCount} / {totalProfilesCapacity || 0}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 mb-6">
        <button onClick={() => setActiveTab('clients')} className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 ${activeTab === 'clients' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
          <Users size={18} /> Clientes
        </button>
        <button onClick={() => setActiveTab('providers')} className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 ${activeTab === 'providers' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
          <Server size={18} /> Proveedores
        </button>
      </div>

      {/* Tab Content */}
      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
        
        {/* CLIENTS SECTION */}
        {activeTab === 'clients' && (
          <div>
            <form onSubmit={addClient} className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
              <input required placeholder="Nombre" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={clientForm.name} onChange={e => setClientForm({...clientForm, name: e.target.value})} />
              <input required placeholder="Teléfono (Ej: 12345678)" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={clientForm.phone} onChange={e => setClientForm({...clientForm, phone: e.target.value})} />
              <select required className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={clientForm.providerId} onChange={e => setClientForm({...clientForm, providerId: e.target.value})}>
                <option value="">Seleccionar Cuenta...</option>
                {providers.map(p => <option key={p.id} value={p.id}>{p.platform} - {p.email}</option>)}
              </select>
              <input required type="date" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={clientForm.date} onChange={e => setClientForm({...clientForm, date: e.target.value})} />
              <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-lg flex items-center justify-center gap-2 font-medium">
                <Plus size={18} /> Agregar
              </button>
            </form>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-700 text-slate-400">
                    <th className="p-3">Cliente</th>
                    <th className="p-3">Cuenta/Plataforma</th>
                    <th className="p-3">Días</th>
                    <th className="p-3 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {clients.sort((a,b) => calculateDays(a.date) - calculateDays(b.date)).map(c => {
                    const days = calculateDays(c.date);
                    const provider = providers.find(p => p.id === c.providerId);
                    return (
                      <tr key={c.id} className={`border-b border-slate-700/50 ${getStatusColor(days)}`}>
                        <td className="p-3 font-medium">{c.name}<br/><span className="text-sm opacity-70">{c.phone}</span></td>
                        <td className="p-3">{provider ? `${provider.platform}` : 'N/A'}<br/><span className="text-sm opacity-70">{provider?.email}</span></td>
                        <td className="p-3 font-bold">{days} {days === 1 || days === -1 ? 'día' : 'días'}</td>
                        <td className="p-3">
                          <div className="flex justify-end gap-2">
                            <a href={getWhatsAppLink(c.phone, c.name, days, provider?.platform)} target="_blank" rel="noreferrer" className="p-2 bg-emerald-600/20 text-emerald-400 rounded hover:bg-emerald-600 hover:text-white transition" title="Enviar WhatsApp">
                              <MessageCircle size={18} />
                            </a>
                            <button onClick={() => renew(c.id, 30, 'client')} className="p-2 bg-indigo-600/20 text-indigo-400 rounded hover:bg-indigo-600 hover:text-white transition" title="+30 Días">
                              <RefreshCw size={18} />
                            </button>
                            <button onClick={() => deleteClient(c.id)} className="p-2 bg-red-600/20 text-red-400 rounded hover:bg-red-600 hover:text-white transition" title="Eliminar">
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                  {clients.length === 0 && <tr><td colSpan="4" className="text-center p-8 text-slate-500">No hay clientes registrados</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PROVIDERS SECTION */}
        {activeTab === 'providers' && (
          <div>
            <form onSubmit={addProvider} className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-8">
              <input required placeholder="Plataforma (Netflix, Max...)" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={providerForm.platform} onChange={e => setProviderForm({...providerForm, platform: e.target.value})} />
              <input required type="email" placeholder="Correo de cuenta" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white md:col-span-2" value={providerForm.email} onChange={e => setProviderForm({...providerForm, email: e.target.value})} />
              <input required type="number" placeholder="Perfiles" min="1" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={providerForm.maxProfiles} onChange={e => setProviderForm({...providerForm, maxProfiles: e.target.value})} />
              <input required type="date" className="bg-slate-900 border border-slate-700 p-2 rounded-lg text-white" value={providerForm.date} onChange={e => setProviderForm({...providerForm, date: e.target.value})} />
              <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-lg flex items-center justify-center gap-2 font-medium">
                <Plus size={18} /> Agregar
              </button>
            </form>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-700 text-slate-400">
                    <th className="p-3">Cuenta Madre</th>
                    <th className="p-3">Ocupación</th>
                    <th className="p-3">Días Madre</th>
                    <th className="p-3 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {providers.sort((a,b) => calculateDays(a.date) - calculateDays(b.date)).map(p => {
                    const days = calculateDays(p.date);
                    const occupied = clients.filter(c => c.providerId === p.id).length;
                    return (
                      <tr key={p.id} className={`border-b border-slate-700/50 ${getStatusColor(days)}`}>
                        <td className="p-3 font-medium">{p.platform}<br/><span className="text-sm opacity-70">{p.email}</span></td>
                        <td className="p-3 font-bold">{occupied} / {p.maxProfiles}</td>
                        <td className="p-3 font-bold flex items-center gap-2"><Clock size={16}/> {days} días</td>
                        <td className="p-3">
                          <div className="flex justify-end gap-2">
                            <button onClick={() => renew(p.id, 30, 'provider')} className="p-2 bg-indigo-600/20 text-indigo-400 rounded hover:bg-indigo-600 hover:text-white transition" title="Renovar +30 Días">
                              <RefreshCw size={18} />
                            </button>
                            <button onClick={() => deleteProvider(p.id)} className="p-2 bg-red-600/20 text-red-400 rounded hover:bg-red-600 hover:text-white transition" title="Eliminar">
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                  {providers.length === 0 && <tr><td colSpan="4" className="text-center p-8 text-slate-500">No hay cuentas madre registradas</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
